package com.stx.p1;

public class Demo_p1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=3;
		int s=1;
		while(s <= 10000) {
			s=s*i;
			i=i+2;
		}
		 
		System.out.println(i);
			
			
		
	}

}
