package com.stx.p5;

public class Demo_p5_2 {

	//ѭ��
	public static void main(String[] args) {
		int nian = 10;
		for(int i = 1; i < 5; i++) {
			nian += 2; 
		}
		System.out.println(nian);
	}
}
